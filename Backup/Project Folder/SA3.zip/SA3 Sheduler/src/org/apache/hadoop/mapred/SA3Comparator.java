/**
 * The Job with highest number of pending tasks should be executed first.
 */
package org.apache.hadoop.mapred;

import java.util.Comparator;

public class SA3Comparator implements Comparator<JobInProgress> {
	public int compare(JobInProgress j1, JobInProgress j2) {
		/* The Job with highest number of pending tasks should be executed first */
		int res = (j2.pendingMaps() + j2.pendingReduces())
				- (j1.pendingMaps() + j1.pendingReduces());

		/* If both the jobs has same number of tasks use FIFO */
		if (res == 0) {
			res = j1.getPriority().compareTo(j2.getPriority());
			if (res == 0) {
				if (j1.getStartTime() < j2.getStartTime()) {
					res = -1;
				} else {
					res = (j1.getStartTime() == j2.getStartTime() ? 0 : 1);
				}
			}
			if (res == 0) {
				res = j1.hashCode() - j2.hashCode();
			}
		}
		return res;
	}
}
