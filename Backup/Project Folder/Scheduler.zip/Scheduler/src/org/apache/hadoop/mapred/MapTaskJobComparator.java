/**
 * The Job with smallest percentage of map tasks executed, should be executed first.
 */

package org.apache.hadoop.mapred;

public class MapTaskJobComparator extends LtfoJobComparator {

    public int compare(JobInProgress j1, JobInProgress j2) {
        /*
         * The Job with smallest percentage of map tasks executed, should be
         * executed first percentage = ( finisheTasks * 100) / desiredTasks
         */
        int res = (j1.finishedMaps() * 100 / j1.desiredMaps())
                - (j2.finishedMaps() * 100 / j2.desiredMaps());

        if (res == 0) {
            return super.compare(j1, j2);
        }

        return res;
    }
}
