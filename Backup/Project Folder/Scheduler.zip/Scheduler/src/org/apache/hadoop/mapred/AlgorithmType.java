package org.apache.hadoop.mapred;

public enum AlgorithmType {
  FIFO,
  FAIR,
  LTFO,
  MAPPERCENT,
  PENDINGFIRST
}
