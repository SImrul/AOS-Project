/**
 * The Job with highest number of pending tasks should be executed first.
 */

package org.apache.hadoop.mapred;

public class PendingTaskJobComparator extends MapTaskJobComparator {
    public int compare(JobInProgress j1, JobInProgress j2) {
        /**/
        int res = (j1.pendingMaps() + j1.pendingReduces()) -
                   (j2.pendingMaps() + j2.pendingReduces());

        if (res == 0) {
            return super.compare(j1, j2);
        }
        return res;
    }
}
