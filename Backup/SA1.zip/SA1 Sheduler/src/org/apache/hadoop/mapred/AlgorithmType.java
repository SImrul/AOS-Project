package org.apache.hadoop.mapred;

public enum AlgorithmType {
  FIFO,
  FAIR,
  LTFO, //Least task first out
  MAPPERCENT, // No of completed percentage
  PENDINGFIRST // No of pending task
}
