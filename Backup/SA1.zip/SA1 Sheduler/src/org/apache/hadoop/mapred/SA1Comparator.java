/**
 * The Job with least number of tasks (map + reduce) should be executed first.- SA1
 */

package org.apache.hadoop.mapred;

import java.util.Comparator;

public class SA1Comparator implements Comparator<JobInProgress> {
    public int compare(JobInProgress j1, JobInProgress j2) {
        /* Job with least number of tasks should be executed first */
        int res = (j1.desiredMaps() + j1.desiredReduces())
                - (j2.desiredMaps() + j2.desiredReduces());

        /* If both the jobs has same number of tasks use FIFO */
        if (res == 0) {
            res = j1.getPriority().compareTo(j2.getPriority());
            if (res == 0) {
                if (j1.getStartTime() < j2.getStartTime()) {
                    res = -1;
                } else {
                    res = (j1.getStartTime() == j2.getStartTime() ? 0 : 1);
                }
            }
            if (res == 0) {
                res = j1.hashCode() - j2.hashCode();
            }
        }
        return res;
    }
}
